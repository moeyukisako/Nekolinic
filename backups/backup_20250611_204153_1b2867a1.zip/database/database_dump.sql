BEGIN TRANSACTION;
CREATE TABLE appointments (
	id INTEGER NOT NULL, 
	appointment_time DATETIME NOT NULL, 
	status VARCHAR(9) NOT NULL, 
	patient_id INTEGER NOT NULL, 
	doctor_id INTEGER NOT NULL, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(patient_id) REFERENCES patients (id), 
	FOREIGN KEY(doctor_id) REFERENCES doctors (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
CREATE TABLE appointments_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	appointment_time DATETIME, 
	status VARCHAR(50), 
	patient_id INTEGER, 
	doctor_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
CREATE TABLE bill_items (
	id INTEGER NOT NULL, 
	item_name VARCHAR(200) NOT NULL, 
	item_type VARCHAR(50) NOT NULL, 
	quantity INTEGER NOT NULL, 
	unit_price NUMERIC(10, 2) NOT NULL, 
	subtotal NUMERIC(10, 2) NOT NULL, 
	bill_id INTEGER NOT NULL, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(bill_id) REFERENCES bills (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "bill_items" VALUES(1,'setraline（50mg）','药物',53,7,371,1,'2025-06-11 02:58:29.494336','2025-06-11 02:58:29.494336',1,1,NULL);
CREATE TABLE bill_items_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	item_name VARCHAR(200), 
	item_type VARCHAR(50), 
	quantity INTEGER, 
	unit_price NUMERIC(10, 2), 
	subtotal NUMERIC(10, 2), 
	bill_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id)
);
INSERT INTO "bill_items_history" VALUES(1,'INSERT','2025-06-11 02:58:29.509369',1,NULL,'setraline（50mg）','药物',53,7,371,1,'2025-06-11 02:58:29.494336','2025-06-11 02:58:29.494336',1,1,NULL);
CREATE TABLE bills (
	id INTEGER NOT NULL, 
	invoice_number VARCHAR(50) NOT NULL, 
	bill_date DATETIME NOT NULL, 
	total_amount NUMERIC(10, 2) NOT NULL, 
	status VARCHAR(14) NOT NULL, 
	patient_id INTEGER NOT NULL, 
	medical_record_id INTEGER, 
	payment_method VARCHAR, 
	provider_transaction_id VARCHAR, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(patient_id) REFERENCES patients (id), 
	FOREIGN KEY(medical_record_id) REFERENCES medical_records (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "bills" VALUES(1,'INV-655BB7F4','2025-06-11 02:58:29.494336',371,'UNPAID',1,1,NULL,NULL,'2025-06-11 02:58:29.494336','2025-06-11 02:58:29.494336',1,1,NULL);
CREATE TABLE bills_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	invoice_number VARCHAR(50), 
	bill_date DATETIME, 
	total_amount NUMERIC(10, 2), 
	status VARCHAR(20), 
	patient_id INTEGER, 
	medical_record_id INTEGER, 
	payment_method VARCHAR, 
	provider_transaction_id VARCHAR, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id)
);
INSERT INTO "bills_history" VALUES(1,'INSERT','2025-06-11 02:58:29.494336',1,NULL,'INV-655BB7F4','2025-06-11 02:58:29.494336',0,'unpaid',1,1,NULL,NULL,'2025-06-11 02:58:29.494336','2025-06-11 02:58:29.494336',1,1,NULL);
INSERT INTO "bills_history" VALUES(2,'UPDATE','2025-06-11 02:58:29.511482',1,1,'INV-655BB7F4','2025-06-11 02:58:29.494336',371,'unpaid',1,1,NULL,NULL,'2025-06-11 02:58:29.494336','2025-06-11 02:58:29.494336',1,1,NULL);
CREATE TABLE clinics (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	address VARCHAR(200), 
	contact_number VARCHAR(20), 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "clinics" VALUES(1,'Nekolinic 总院','互联网','010-88888888','2025-06-11 02:56:41.542856','2025-06-11 02:56:41.542856',NULL,NULL,NULL);
CREATE TABLE doctors (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	title VARCHAR(50), 
	specialty VARCHAR(100) NOT NULL, 
	phone VARCHAR(20), 
	email VARCHAR(100), 
	user_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (user_id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "doctors" VALUES(1,'admin',NULL,'系统管理',NULL,NULL,1,'2025-06-11 02:56:41.551187','2025-06-11 02:56:41.551187',NULL,NULL,NULL);
INSERT INTO "doctors" VALUES(2,'doctor',NULL,'全科医学',NULL,NULL,2,'2025-06-11 02:56:41.813069','2025-06-11 02:56:41.813069',NULL,NULL,NULL);
CREATE TABLE doctors_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	name VARCHAR(100), 
	title VARCHAR(50), 
	specialty VARCHAR(100), 
	phone VARCHAR(20), 
	email VARCHAR(100), 
	user_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "doctors_history" VALUES(1,'INSERT','2025-06-11 02:56:41.551187',NULL,NULL,'admin',NULL,'系统管理',NULL,NULL,1,'2025-06-11 02:56:41.551187','2025-06-11 02:56:41.551187',NULL,NULL,NULL);
INSERT INTO "doctors_history" VALUES(2,'INSERT','2025-06-11 02:56:41.813069',NULL,NULL,'doctor',NULL,'全科医学',NULL,NULL,2,'2025-06-11 02:56:41.813069','2025-06-11 02:56:41.813069',NULL,NULL,NULL);
CREATE TABLE drugs (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	code VARCHAR(50), 
	description TEXT, 
	specification VARCHAR(100), 
	manufacturer VARCHAR(100), 
	unit VARCHAR(20), 
	unit_price NUMERIC(10, 2) NOT NULL, 
	cost_price NUMERIC(10, 2), 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (code), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "drugs" VALUES(1,'setraline','SETRALINE',NULL,'50mg','pfizer','片',7,5,'2025-06-11 02:58:03.847019','2025-06-11 02:58:03.847019',1,1,NULL);
CREATE TABLE drugs_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	name VARCHAR(100), 
	code VARCHAR(50), 
	description TEXT, 
	specification VARCHAR(100), 
	manufacturer VARCHAR(100), 
	unit VARCHAR(20), 
	unit_price NUMERIC(10, 2), 
	cost_price NUMERIC(10, 2), 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id)
);
INSERT INTO "drugs_history" VALUES(1,'INSERT','2025-06-11 02:58:03.847019',1,NULL,'setraline','SETRALINE',NULL,'50mg','pfizer','片',7,5,'2025-06-11 02:58:03.847019','2025-06-11 02:58:03.847019',1,1,NULL);
CREATE TABLE insurances (
	id INTEGER NOT NULL, 
	provider_name VARCHAR(100) NOT NULL, 
	policy_number VARCHAR(100) NOT NULL, 
	patient_id INTEGER NOT NULL, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(patient_id) REFERENCES patients (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
CREATE TABLE insurances_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	provider_name VARCHAR(100), 
	policy_number VARCHAR(100), 
	patient_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id)
);
CREATE TABLE inventory_transactions (
	id INTEGER NOT NULL, 
	transaction_time DATETIME NOT NULL, 
	transaction_type VARCHAR(10) NOT NULL, 
	quantity_change INTEGER NOT NULL, 
	notes TEXT, 
	drug_id INTEGER NOT NULL, 
	action_by_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(drug_id) REFERENCES drugs (id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id)
);
INSERT INTO "inventory_transactions" VALUES(1,'2025-06-11 02:58:11.361119','STOCK_IN',99,NULL,1,1);
CREATE TABLE medical_records (
	id INTEGER NOT NULL, 
	display_id VARCHAR(50) NOT NULL, 
	record_date DATETIME NOT NULL, 
	chief_complaint TEXT, 
	present_illness TEXT, 
	past_history TEXT, 
	temperature FLOAT, 
	pulse INTEGER, 
	respiratory_rate INTEGER, 
	blood_pressure VARCHAR(20), 
	physical_examination TEXT, 
	diagnosis TEXT, 
	treatment_plan TEXT, 
	prescription TEXT, 
	notes TEXT, 
	symptoms TEXT, 
	patient_id INTEGER NOT NULL, 
	doctor_id INTEGER NOT NULL, 
	appointment_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(patient_id) REFERENCES patients (id), 
	FOREIGN KEY(doctor_id) REFERENCES doctors (id), 
	UNIQUE (appointment_id), 
	FOREIGN KEY(appointment_id) REFERENCES appointments (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "medical_records" VALUES(1,'MR-001-20250611105732','2025-06-11 00:00:00.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'a',NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL);
CREATE TABLE medical_records_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	display_id VARCHAR(50), 
	record_date DATETIME, 
	chief_complaint TEXT, 
	present_illness TEXT, 
	past_history TEXT, 
	temperature FLOAT, 
	pulse INTEGER, 
	respiratory_rate INTEGER, 
	blood_pressure VARCHAR(20), 
	physical_examination TEXT, 
	diagnosis TEXT, 
	treatment_plan TEXT, 
	prescription TEXT, 
	notes TEXT, 
	symptoms TEXT, 
	patient_id INTEGER, 
	doctor_id INTEGER, 
	appointment_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "medical_records_history" VALUES(1,'INSERT','2025-06-11 02:57:32.577964',1,NULL,'MR-001-20250611105732','2025-06-11 00:00:00.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'a',NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL);
CREATE TABLE merged_payment_session_bills (
	id INTEGER NOT NULL, 
	merged_session_id INTEGER NOT NULL, 
	bill_id INTEGER NOT NULL, 
	bill_amount NUMERIC(10, 2) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(merged_session_id) REFERENCES merged_payment_sessions (id), 
	FOREIGN KEY(bill_id) REFERENCES bills (id)
);
CREATE TABLE merged_payment_sessions (
	id INTEGER NOT NULL, 
	session_id VARCHAR(100) NOT NULL, 
	patient_id INTEGER NOT NULL, 
	total_amount NUMERIC(10, 2) NOT NULL, 
	payment_method VARCHAR(20) NOT NULL, 
	qr_code_content TEXT, 
	status VARCHAR(9) NOT NULL, 
	expires_at DATETIME NOT NULL, 
	prepay_id VARCHAR(100), 
	provider_transaction_id VARCHAR(100), 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(patient_id) REFERENCES patients (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
CREATE TABLE patients (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	birth_date DATE, 
	gender VARCHAR(10), 
	contact_number VARCHAR(20), 
	address VARCHAR(200), 
	past_medical_history TEXT, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "patients" VALUES(1,'张星彩','2009-03-11','female','39',NULL,NULL,'2025-06-11 02:57:19.407545','2025-06-11 02:57:19.407545',1,1,NULL);
CREATE TABLE patients_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	name VARCHAR(100), 
	birth_date DATE, 
	gender VARCHAR(10), 
	contact_number VARCHAR(20), 
	address VARCHAR(200), 
	past_medical_history TEXT, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "patients_history" VALUES(1,'INSERT','2025-06-11 02:57:19.408063',1,NULL,'张星彩','2009-03-11','female','39',NULL,NULL,'2025-06-11 02:57:19.407545','2025-06-11 02:57:19.407545',1,1,NULL);
CREATE TABLE payment_sessions (
	id INTEGER NOT NULL, 
	bill_id INTEGER NOT NULL, 
	payment_method VARCHAR(10) NOT NULL, 
	qr_code_content TEXT NOT NULL, 
	expires_at DATETIME NOT NULL, 
	status VARCHAR(9) NOT NULL, 
	prepay_id VARCHAR(100), 
	amount NUMERIC(10, 2) NOT NULL, 
	timeout_minutes INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	created_by_id INTEGER NOT NULL, 
	updated_by_id INTEGER NOT NULL, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(bill_id) REFERENCES bills (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
CREATE TABLE payments (
	id INTEGER NOT NULL, 
	payment_date DATETIME NOT NULL, 
	amount NUMERIC(10, 2) NOT NULL, 
	payment_method VARCHAR(9) NOT NULL, 
	payment_mode VARCHAR(8) NOT NULL, 
	provider_transaction_id VARCHAR(100), 
	qr_code_url VARCHAR(500), 
	qr_code_expires_at DATETIME, 
	bill_id INTEGER NOT NULL, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(bill_id) REFERENCES bills (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
CREATE TABLE payments_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	payment_date DATETIME, 
	amount NUMERIC(10, 2), 
	payment_method VARCHAR(20), 
	payment_mode VARCHAR(20), 
	provider_transaction_id VARCHAR(100), 
	qr_code_url VARCHAR(500), 
	qr_code_expires_at DATETIME, 
	bill_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id)
);
CREATE TABLE prescription_details (
	id INTEGER NOT NULL, 
	dosage VARCHAR(100), 
	frequency VARCHAR(100), 
	days INTEGER, 
	quantity INTEGER NOT NULL, 
	prescription_id INTEGER NOT NULL, 
	drug_id INTEGER NOT NULL, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(prescription_id) REFERENCES prescriptions (id), 
	FOREIGN KEY(drug_id) REFERENCES drugs (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "prescription_details" VALUES(1,'','3',3,53,1,1,'2025-06-11 02:58:29.442716','2025-06-11 02:58:29.442716',1,1,NULL);
CREATE TABLE prescription_details_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	dosage VARCHAR(100), 
	frequency VARCHAR(100), 
	days INTEGER, 
	quantity INTEGER, 
	prescription_id INTEGER, 
	drug_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id)
);
INSERT INTO "prescription_details_history" VALUES(1,'INSERT','2025-06-11 02:58:29.476531',1,NULL,'','3',3,53,1,1,'2025-06-11 02:58:29.442716','2025-06-11 02:58:29.442716',1,1,NULL);
CREATE TABLE prescriptions (
	id INTEGER NOT NULL, 
	prescription_date DATETIME NOT NULL, 
	dispensing_status VARCHAR(9) NOT NULL, 
	medical_record_id INTEGER NOT NULL, 
	doctor_id INTEGER NOT NULL, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(medical_record_id) REFERENCES medical_records (id), 
	FOREIGN KEY(doctor_id) REFERENCES doctors (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "prescriptions" VALUES(1,'2025-06-11 02:58:00.000000','PENDING',1,1,'2025-06-11 02:58:29.442716','2025-06-11 02:58:29.442716',1,1,NULL);
CREATE TABLE prescriptions_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	prescription_date DATETIME, 
	dispensing_status VARCHAR(50), 
	medical_record_id INTEGER, 
	doctor_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id)
);
INSERT INTO "prescriptions_history" VALUES(1,'INSERT','2025-06-11 02:58:29.444181',1,NULL,'2025-06-11 02:58:00.000000','pending',1,1,'2025-06-11 02:58:29.442716','2025-06-11 02:58:29.442716',1,1,NULL);
CREATE TABLE users (
	id INTEGER NOT NULL, 
	username VARCHAR(50) NOT NULL, 
	email VARCHAR(100) NOT NULL, 
	full_name VARCHAR(100), 
	hashed_password VARCHAR(255) NOT NULL, 
	role VARCHAR(50) NOT NULL, 
	is_active BOOLEAN, 
	background_preference VARCHAR(255), 
	preferences JSON, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "users" VALUES(1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 12:41:50.890558',NULL,1,NULL);
INSERT INTO "users" VALUES(2,'doctor','doctor@nekolinic.com','测试医生','$2b$12$ZWY4mrMbURJ1/a3W.NLfoe724HszboAMwfOT5ZWDm0F.Yp4tWtEJS','doctor',1,NULL,'null',NULL,NULL,NULL,NULL,NULL);
CREATE TABLE users_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	username VARCHAR(50), 
	email VARCHAR(100), 
	full_name VARCHAR(100), 
	hashed_password VARCHAR(255), 
	role VARCHAR(50), 
	is_active BOOLEAN, 
	background_preference VARCHAR(255), 
	preferences JSON, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
INSERT INTO "users_history" VALUES(1,'INSERT','2025-06-11 02:56:41.493868',NULL,NULL,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'null',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "users_history" VALUES(2,'INSERT','2025-06-11 02:56:41.775188',NULL,NULL,'doctor','doctor@nekolinic.com','测试医生','$2b$12$ZWY4mrMbURJ1/a3W.NLfoe724HszboAMwfOT5ZWDm0F.Yp4tWtEJS','doctor',1,NULL,'null',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "users_history" VALUES(3,'UPDATE','2025-06-11 08:49:44.003662',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 08:49:44.002660',NULL,1,NULL);
INSERT INTO "users_history" VALUES(4,'UPDATE','2025-06-11 08:50:13.185740',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 08:50:13.185740',NULL,1,NULL);
INSERT INTO "users_history" VALUES(5,'UPDATE','2025-06-11 08:50:13.208694',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 08:50:13.208694',NULL,1,NULL);
INSERT INTO "users_history" VALUES(6,'UPDATE','2025-06-11 08:50:13.678909',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 08:50:13.678909',NULL,1,NULL);
INSERT INTO "users_history" VALUES(7,'UPDATE','2025-06-11 09:12:17.582278',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:12:17.582278',NULL,1,NULL);
INSERT INTO "users_history" VALUES(8,'UPDATE','2025-06-11 09:12:19.633435',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:12:19.633435',NULL,1,NULL);
INSERT INTO "users_history" VALUES(9,'UPDATE','2025-06-11 09:12:20.118563',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:12:20.118563',NULL,1,NULL);
INSERT INTO "users_history" VALUES(10,'UPDATE','2025-06-11 09:22:10.701405',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:22:10.701405',NULL,1,NULL);
INSERT INTO "users_history" VALUES(11,'UPDATE','2025-06-11 09:45:02.536740',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:45:02.536220',NULL,1,NULL);
INSERT INTO "users_history" VALUES(12,'UPDATE','2025-06-11 09:45:07.544836',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:45:07.544836',NULL,1,NULL);
INSERT INTO "users_history" VALUES(13,'UPDATE','2025-06-11 09:45:11.675387',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:45:11.675387',NULL,1,NULL);
INSERT INTO "users_history" VALUES(14,'UPDATE','2025-06-11 09:45:12.161772',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:45:12.161772',NULL,1,NULL);
INSERT INTO "users_history" VALUES(15,'UPDATE','2025-06-11 09:45:15.706359',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:45:15.706359',NULL,1,NULL);
INSERT INTO "users_history" VALUES(16,'UPDATE','2025-06-11 09:45:17.185151',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:45:17.185151',NULL,1,NULL);
INSERT INTO "users_history" VALUES(17,'UPDATE','2025-06-11 09:45:18.668246',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:45:18.668246',NULL,1,NULL);
INSERT INTO "users_history" VALUES(18,'UPDATE','2025-06-11 09:45:19.159020',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:45:19.157617',NULL,1,NULL);
INSERT INTO "users_history" VALUES(19,'UPDATE','2025-06-11 09:45:24.091945',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:45:24.091945',NULL,1,NULL);
INSERT INTO "users_history" VALUES(20,'UPDATE','2025-06-11 09:52:01.782500',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 09:52:01.782500',NULL,1,NULL);
INSERT INTO "users_history" VALUES(21,'UPDATE','2025-06-11 10:01:49.744472',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:01:49.744472',NULL,1,NULL);
INSERT INTO "users_history" VALUES(22,'UPDATE','2025-06-11 10:01:58.177214',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:01:58.177214',NULL,1,NULL);
INSERT INTO "users_history" VALUES(23,'UPDATE','2025-06-11 10:01:59.229884',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:01:59.228881',NULL,1,NULL);
INSERT INTO "users_history" VALUES(24,'UPDATE','2025-06-11 10:01:59.715477',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:01:59.715477',NULL,1,NULL);
INSERT INTO "users_history" VALUES(25,'UPDATE','2025-06-11 10:02:07.962448',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:02:07.962448',NULL,1,NULL);
INSERT INTO "users_history" VALUES(26,'UPDATE','2025-06-11 10:02:08.001673',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:02:08.001673',NULL,1,NULL);
INSERT INTO "users_history" VALUES(27,'UPDATE','2025-06-11 10:02:09.464188',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:02:09.464188',NULL,1,NULL);
INSERT INTO "users_history" VALUES(28,'UPDATE','2025-06-11 10:02:09.955240',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:02:09.955240',NULL,1,NULL);
INSERT INTO "users_history" VALUES(29,'UPDATE','2025-06-11 10:02:15.908541',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:02:15.908541',NULL,1,NULL);
INSERT INTO "users_history" VALUES(30,'UPDATE','2025-06-11 10:02:17.057409',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:02:17.057409',NULL,1,NULL);
INSERT INTO "users_history" VALUES(31,'UPDATE','2025-06-11 10:02:17.540914',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:02:17.540402',NULL,1,NULL);
INSERT INTO "users_history" VALUES(32,'UPDATE','2025-06-11 10:12:13.050778',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:12:13.050778',NULL,1,NULL);
INSERT INTO "users_history" VALUES(33,'UPDATE','2025-06-11 10:12:13.084967',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:12:13.084967',NULL,1,NULL);
INSERT INTO "users_history" VALUES(34,'UPDATE','2025-06-11 10:12:14.414280',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:12:14.414280',NULL,1,NULL);
INSERT INTO "users_history" VALUES(35,'UPDATE','2025-06-11 10:12:14.899447',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:12:14.899447',NULL,1,NULL);
INSERT INTO "users_history" VALUES(36,'UPDATE','2025-06-11 10:33:52.814931',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:33:52.814931',NULL,1,NULL);
INSERT INTO "users_history" VALUES(37,'UPDATE','2025-06-11 10:33:54.200411',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:33:54.200411',NULL,1,NULL);
INSERT INTO "users_history" VALUES(38,'UPDATE','2025-06-11 10:33:54.685167',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:33:54.684447',NULL,1,NULL);
INSERT INTO "users_history" VALUES(39,'UPDATE','2025-06-11 10:33:56.456734',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:33:56.456734',NULL,1,NULL);
INSERT INTO "users_history" VALUES(40,'UPDATE','2025-06-11 10:33:59.601817',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:33:59.601817',NULL,1,NULL);
INSERT INTO "users_history" VALUES(41,'UPDATE','2025-06-11 10:33:59.616080',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:33:59.616080',NULL,1,NULL);
INSERT INTO "users_history" VALUES(42,'UPDATE','2025-06-11 10:34:00.108760',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:34:00.108760',NULL,1,NULL);
INSERT INTO "users_history" VALUES(43,'UPDATE','2025-06-11 10:34:37.131292',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:34:37.131292',NULL,1,NULL);
INSERT INTO "users_history" VALUES(44,'UPDATE','2025-06-11 10:34:39.457811',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:34:39.457811',NULL,1,NULL);
INSERT INTO "users_history" VALUES(45,'UPDATE','2025-06-11 10:34:39.472170',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:34:39.470786',NULL,1,NULL);
INSERT INTO "users_history" VALUES(46,'UPDATE','2025-06-11 10:34:39.957481',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:34:39.956445',NULL,1,NULL);
INSERT INTO "users_history" VALUES(47,'UPDATE','2025-06-11 10:34:46.723988',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:34:46.723988',NULL,1,NULL);
INSERT INTO "users_history" VALUES(48,'UPDATE','2025-06-11 10:34:48.031711',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:34:48.031711',NULL,1,NULL);
INSERT INTO "users_history" VALUES(49,'UPDATE','2025-06-11 10:34:48.521367',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:34:48.521367',NULL,1,NULL);
INSERT INTO "users_history" VALUES(50,'UPDATE','2025-06-11 10:35:41.338167',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:35:41.336850',NULL,1,NULL);
INSERT INTO "users_history" VALUES(51,'UPDATE','2025-06-11 10:35:46.092869',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:35:46.092869',NULL,1,NULL);
INSERT INTO "users_history" VALUES(52,'UPDATE','2025-06-11 10:41:42.548740',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:41:42.548740',NULL,1,NULL);
INSERT INTO "users_history" VALUES(53,'UPDATE','2025-06-11 10:41:45.721141',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:41:45.721141',NULL,1,NULL);
INSERT INTO "users_history" VALUES(54,'UPDATE','2025-06-11 10:41:45.732750',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:41:45.732750',NULL,1,NULL);
INSERT INTO "users_history" VALUES(55,'UPDATE','2025-06-11 10:41:46.216349',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:41:46.216349',NULL,1,NULL);
INSERT INTO "users_history" VALUES(56,'UPDATE','2025-06-11 10:54:22.038652',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:54:22.038652',NULL,1,NULL);
INSERT INTO "users_history" VALUES(57,'UPDATE','2025-06-11 10:54:23.497171',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:54:23.497171',NULL,1,NULL);
INSERT INTO "users_history" VALUES(58,'UPDATE','2025-06-11 10:54:23.507749',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:54:23.507749',NULL,1,NULL);
INSERT INTO "users_history" VALUES(59,'UPDATE','2025-06-11 10:54:23.996369',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "dark", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 30, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 10:54:23.995846',NULL,1,NULL);
INSERT INTO "users_history" VALUES(60,'UPDATE','2025-06-11 11:11:14.813908',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 32, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 11:11:14.813769',NULL,1,NULL);
INSERT INTO "users_history" VALUES(61,'UPDATE','2025-06-11 12:28:36.445429',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "en-US", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 32, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 12:28:36.445265',NULL,1,NULL);
INSERT INTO "users_history" VALUES(62,'UPDATE','2025-06-11 12:28:37.543776',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 32, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 12:28:37.543677',NULL,1,NULL);
INSERT INTO "users_history" VALUES(63,'UPDATE','2025-06-11 12:28:38.035527',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 32, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 12:28:38.035399',NULL,1,NULL);
INSERT INTO "users_history" VALUES(64,'UPDATE','2025-06-11 12:28:39.961708',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 32, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 12:28:39.961625',NULL,1,NULL);
INSERT INTO "users_history" VALUES(65,'UPDATE','2025-06-11 12:34:50.574744',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 32, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 12:34:50.574604',NULL,1,NULL);
INSERT INTO "users_history" VALUES(66,'UPDATE','2025-06-11 12:37:01.571833',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 32, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 12:37:01.571715',NULL,1,NULL);
INSERT INTO "users_history" VALUES(67,'UPDATE','2025-06-11 12:39:21.070596',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 32, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 12:39:21.070494',NULL,1,NULL);
INSERT INTO "users_history" VALUES(68,'UPDATE','2025-06-11 12:41:50.890639',1,1,'admin','admin@nekolinic.com','系统管理员','$2b$12$YXmLLrPhmsQWuWPVh/PyXO2Y4TVwQnsPsek1DpqZh2XxzORm.ajxy','admin',1,NULL,'{"theme": "light", "language": "zh-CN", "autoSave": true, "showTooltips": true, "desktopNotifications": true, "soundNotifications": true, "emailNotifications": false, "sessionTimeout": 32, "autoBackup": false, "backupFrequency": "daily"}',NULL,'2025-06-11 12:41:50.890558',NULL,1,NULL);
CREATE TABLE vital_signs (
	id INTEGER NOT NULL, 
	temperature FLOAT, 
	heart_rate INTEGER, 
	blood_pressure VARCHAR(20), 
	respiratory_rate INTEGER, 
	oxygen_saturation FLOAT, 
	medical_record_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (medical_record_id), 
	FOREIGN KEY(medical_record_id) REFERENCES medical_records (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
CREATE TABLE vital_signs_history (
	history_id INTEGER NOT NULL, 
	action_type VARCHAR(10) NOT NULL, 
	action_timestamp DATETIME NOT NULL, 
	action_by_id INTEGER, 
	id INTEGER, 
	temperature FLOAT, 
	heart_rate INTEGER, 
	blood_pressure VARCHAR(20), 
	respiratory_rate INTEGER, 
	oxygen_saturation FLOAT, 
	medical_record_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	created_by_id INTEGER, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	PRIMARY KEY (history_id), 
	FOREIGN KEY(action_by_id) REFERENCES users (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(updated_by_id) REFERENCES users (id)
);
CREATE UNIQUE INDEX ix_users_username ON users (username);
CREATE UNIQUE INDEX ix_users_email ON users (email);
CREATE INDEX ix_users_id ON users (id);
CREATE INDEX ix_patients_history_id ON patients_history (id);
CREATE INDEX ix_patients_history_history_id ON patients_history (history_id);
CREATE INDEX ix_medical_records_history_history_id ON medical_records_history (history_id);
CREATE INDEX ix_medical_records_history_id ON medical_records_history (id);
CREATE INDEX ix_vital_signs_history_history_id ON vital_signs_history (history_id);
CREATE INDEX ix_vital_signs_history_id ON vital_signs_history (id);
CREATE INDEX ix_patients_id ON patients (id);
CREATE INDEX ix_doctors_history_id ON doctors_history (id);
CREATE INDEX ix_doctors_history_history_id ON doctors_history (history_id);
CREATE INDEX ix_appointments_history_history_id ON appointments_history (history_id);
CREATE INDEX ix_appointments_history_id ON appointments_history (id);
CREATE INDEX ix_clinics_id ON clinics (id);
CREATE INDEX ix_doctors_id ON doctors (id);
CREATE INDEX ix_insurances_history_id ON insurances_history (id);
CREATE INDEX ix_insurances_history_history_id ON insurances_history (history_id);
CREATE INDEX ix_bills_history_id ON bills_history (id);
CREATE INDEX ix_bills_history_history_id ON bills_history (history_id);
CREATE INDEX ix_bill_items_history_id ON bill_items_history (id);
CREATE INDEX ix_bill_items_history_history_id ON bill_items_history (history_id);
CREATE INDEX ix_payments_history_id ON payments_history (id);
CREATE INDEX ix_payments_history_history_id ON payments_history (history_id);
CREATE INDEX ix_drugs_history_id ON drugs_history (id);
CREATE INDEX ix_drugs_history_history_id ON drugs_history (history_id);
CREATE INDEX ix_prescriptions_history_history_id ON prescriptions_history (history_id);
CREATE INDEX ix_prescriptions_history_id ON prescriptions_history (id);
CREATE INDEX ix_prescription_details_history_history_id ON prescription_details_history (history_id);
CREATE INDEX ix_prescription_details_history_id ON prescription_details_history (id);
CREATE INDEX ix_drugs_id ON drugs (id);
CREATE INDEX ix_drugs_name ON drugs (name);
CREATE INDEX ix_users_history_id ON users_history (id);
CREATE INDEX ix_users_history_history_id ON users_history (history_id);
CREATE INDEX ix_appointments_id ON appointments (id);
CREATE INDEX ix_insurances_id ON insurances (id);
CREATE INDEX ix_merged_payment_sessions_patient_id ON merged_payment_sessions (patient_id);
CREATE UNIQUE INDEX ix_merged_payment_sessions_session_id ON merged_payment_sessions (session_id);
CREATE INDEX ix_merged_payment_sessions_id ON merged_payment_sessions (id);
CREATE INDEX ix_inventory_transactions_id ON inventory_transactions (id);
CREATE UNIQUE INDEX ix_medical_records_display_id ON medical_records (display_id);
CREATE INDEX ix_medical_records_id ON medical_records (id);
CREATE INDEX ix_vital_signs_id ON vital_signs (id);
CREATE UNIQUE INDEX ix_bills_invoice_number ON bills (invoice_number);
CREATE INDEX ix_bills_id ON bills (id);
CREATE INDEX ix_bills_provider_transaction_id ON bills (provider_transaction_id);
CREATE INDEX ix_prescriptions_id ON prescriptions (id);
CREATE INDEX ix_bill_items_id ON bill_items (id);
CREATE INDEX ix_payments_id ON payments (id);
CREATE INDEX ix_merged_payment_session_bills_id ON merged_payment_session_bills (id);
CREATE INDEX ix_payment_sessions_expires_at ON payment_sessions (expires_at);
CREATE INDEX ix_payment_sessions_status ON payment_sessions (status);
CREATE INDEX ix_payment_sessions_bill_id ON payment_sessions (bill_id);
CREATE INDEX ix_payment_sessions_id ON payment_sessions (id);
CREATE INDEX ix_prescription_details_id ON prescription_details (id);
COMMIT;
